import React from 'react'
import Form from './form'

function App() {
  return (
    <div>
      <Form/>
    </div>
  )
}

export default App
