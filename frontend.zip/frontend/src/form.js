import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Form as BootstrapForm, Container, Row, Col, Card } from 'react-bootstrap';
import axios from 'axios';

function Form() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    state: '',
    city: '',
    password: '',
    email: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const userPost = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/post', formData);
      if (response.status === 201) {
        setFormData({
          name: '',
          address: '',
          state: '',
          city: '',
          password: '',
          email: ''
        });
        setIsSubmitted(false); // Set editMode to true upon successful form submission
        setTimeout(()=>{
          setIsSubmitted(false);
        },2000)
      }
    } catch (error) {
      console.error('Error submitting form:', error.response ? error.response.data : error.message);
      // Optionally handle and display error messages here
    }
  };

  return (
    <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh',backgroundColor:'lightblue' }} >
      <Row>
        <Col>
          <Card style={{ width: '400px', padding: '20px', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', textAlign: 'left' , backgroundColor:"gray"}}>
            <Card.Body>
              <Card.Title className="text-center">Registration Form</Card.Title>
              <BootstrapForm onSubmit={userPost}>
                <BootstrapForm.Group controlId="formUserId">
                  <BootstrapForm.Label>Name</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="text"
                    placeholder="Enter Name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>
                <BootstrapForm.Group controlId="formSignUpEmail" className="mt-3">
                  <BootstrapForm.Label>Email</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="email"
                    placeholder="Enter Email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>
                <BootstrapForm.Group controlId="formAddress" className="mt-3">
                  <BootstrapForm.Label>Address</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="text"
                    placeholder="Enter Address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>

                <BootstrapForm.Group controlId="formState" className="mt-3">
                  <BootstrapForm.Label>State</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="text"
                    placeholder="Enter State"
                    name="state"
                    value={formData.state}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>
                <BootstrapForm.Group controlId="formCity" className="mt-3">
                  <BootstrapForm.Label>City</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="text"
                    placeholder="Enter City"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>
                
                <BootstrapForm.Group controlId="formSignUpPassword" className="mt-3">
                  <BootstrapForm.Label>Password</BootstrapForm.Label>
                  <BootstrapForm.Control
                    type="password"
                    placeholder="Enter Password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </BootstrapForm.Group>
                {isSubmitted ? (
                  <p>Form Submitted Successfully!</p>
                ) : (
                  <Button variant="primary" type="submit" className="mt-3 w-100">
                    Submit
                  </Button>
                )}
              </BootstrapForm>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Form;
